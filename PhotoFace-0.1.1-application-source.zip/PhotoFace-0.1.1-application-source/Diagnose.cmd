@echo off
"%~dp0Python\python.exe" -I "%~dp0Runtime\self_test.py" --game
pause
