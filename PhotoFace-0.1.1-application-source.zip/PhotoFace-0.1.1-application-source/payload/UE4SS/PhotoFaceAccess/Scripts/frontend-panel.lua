-- Attach only PhotoFace's existing HTML container while the character editor is visible.
-- The stock frontend creates the container without adding it to the viewport.
local function editor_open()
 for _,w in ipairs(FindAllOf('B1CharacterCustomizationWidget') or {}) do
  if w:IsValid() then
   local visibility=w:GetVisibility()
   if visibility==0 or visibility==3 or visibility==4 then return true end
  end
 end
 return false
end
LoopInGameThreadWithDelay(500,function()
 local ok,err=pcall(function()
  local visible=editor_open()
  for _,v in ipairs(FindAllOf('B1UIModView') or {}) do
   if v:IsValid() and v.modId:ToString()=='PhotoFace_9CYVRD/FaceProbe' then
    local w=v.ContainerWidget
    if w and w:IsValid() then
     if visible then
      if not w:IsInViewport() then w:AddToViewport(10000) end
      w:SetVisibility(4)
      local html=v.CohtmlWidget
      if html and html:IsValid() then html:SetVisibility(3);html.bUseManualMouseInputRouting=false end
     elseif w:IsInViewport() then
      w:RemoveFromParent()
     end
    end
   end
  end
 end)
 if not ok then print('[PhotoFace frontend] '..tostring(err)..'\n') end
end)

