-- Rotate only the editor character; a watchdog restores its original pose.
local source=debug.getinfo(1,'S').source:gsub('^@',''):gsub('\\','/')
local bridge=assert(source:match('^(.*)/Scripts/[^/]+$'))..'/bridge/'
local last,saved='',nil
local folder=assert(source:match('^(.*)/[^/]+$'))
local handler
local function read(key)
 local f=io.open(bridge..key..'.cfg','r');if not f then return '' end
 local v=f:read('*a');f:close();return v
end
local function write(key,v)
 local f=assert(io.open(bridge..key..'.cfg','w'));f:write(v);f:close()
end
local function restore()
 if saved then
  local state=saved;saved=nil
  if handler then pcall(handler,state,0,write) end
  if state.actor:IsValid() then pcall(function() state.actor:K2_SetActorRotation(state.rotation,false) end) end
 end
end
LoopInGameThreadWithDelay(50,function()
 if saved and os.time()>saved.deadline then pcall(restore) end
 local req=read('view_request');if req==last or req=='' then return end;last=req
 local ok,err=pcall(function()
  local angle=tonumber(read('view_yaw'))
  if not angle or math.abs(angle)>65 then error('View yaw must be between -65 and 65') end
  if angle==0 then restore();return end
  if not saved then
   local candidates={}
   for _,actor in ipairs(FindAllOf('B1AppearanceCharacter') or {}) do
    if actor:IsValid() and actor.AppearanceComponent and actor.AppearanceComponent:IsValid() then candidates[#candidates+1]=actor end
   end
   assert(#candidates==1,'Expected one editor character')
   local actor=candidates[1]
   local anchor=actor.TransformAnchor
   if read('view_mode')=='anchor' and anchor and anchor:IsValid() then actor=anchor end
   local r=actor:K2_GetActorRotation()
   saved={actor=actor,rotation={Pitch=r.Pitch,Yaw=r.Yaw,Roll=r.Roll}}
   write('view_debug','actor='..actor:GetFullName()..'; anchor='..(anchor and anchor:IsValid() and anchor:GetFullName() or 'nil')..'; original yaw='..r.Yaw)
  end
  saved.deadline=os.time()+12
  handler=assert(loadfile(folder..'/fit-view-handler.lua'))()
  handler(saved,angle,write)
 end)
 write('view_error',ok and '' or tostring(err));write('view_ack',req)
 if not ok then pcall(restore) end
end)
