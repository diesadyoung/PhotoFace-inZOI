-- Launch the local worker with no visible application window. A worker lock prevents duplicates.
local source=debug.getinfo(1,'S').source:gsub('^@',''):gsub('\\','/')
local base=assert(source:match('^(.*)/Scripts/[^/]+$'))
local f=io.open(base..'/bridge/service_heartbeat.cfg','r')
local heartbeat=f and tonumber(f:read('*a')) or 0
if f then f:close() end
if not heartbeat or os.time()-heartbeat>15 then
 os.execute('wscript.exe "'..base..'/launch-runtime.vbs"')
end
