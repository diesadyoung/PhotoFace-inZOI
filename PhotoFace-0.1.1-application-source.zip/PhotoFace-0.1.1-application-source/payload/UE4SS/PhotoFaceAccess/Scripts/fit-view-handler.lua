return function(saved,angle,write)
 if not saved.mesh then
  for _,m in ipairs(FindAllOf('SkeletalMeshComponent') or {}) do
   if m:IsValid() and m:GetOuter():GetFullName()==saved.actor:GetFullName() and m:GetFName():ToString()=='CharacterMesh0' then
    saved.mesh=m;local r=m.RelativeRotation;saved.meshRotation={Pitch=r.Pitch,Yaw=r.Yaw,Roll=r.Roll};break
   end
  end
  assert(saved.mesh,'Editor body mesh not found')
 end
 local r=saved.meshRotation
 saved.mesh:K2_SetRelativeRotation({Pitch=r.Pitch,Yaw=r.Yaw+angle,Roll=r.Roll},false,{},true)
end
