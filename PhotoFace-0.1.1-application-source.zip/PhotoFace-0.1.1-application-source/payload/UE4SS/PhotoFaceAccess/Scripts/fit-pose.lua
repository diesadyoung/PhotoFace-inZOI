-- Hold only the temporary editor character still during numerical calibration.
local source=debug.getinfo(1,'S').source:gsub('^@',''):gsub('\\','/')
local bridge=assert(source:match('^(.*)/Scripts/[^/]+$'))..'/bridge/'
local held={}
local meshClass=StaticFindObject('/Script/Engine.SkeletalMeshComponent')
local function release()
 for _,entry in pairs(held) do
  if entry.object:IsValid() then entry.object.bPauseAnims=entry.original end
 end
 held={}
end
LoopInGameThreadWithDelay(100,function()
 local f=io.open(bridge..'fit_pose_lease.cfg','r')
 local deadline=f and tonumber(f:read('*a')) or 0
 if f then f:close() end
 if not deadline or deadline<os.time() then release();return end
 local ok,err=pcall(function()
  local actors=FindAllOf('B1AppearanceCharacter') or {}
  if #actors~=1 then error('Editor character changed during fitting') end
  local actorName=actors[1]:GetFullName()
  for _,object in ipairs(FindAllOf('SkeletalMeshComponent') or {}) do
   if object:IsValid() and object:GetOuter():GetFullName()==actorName then
    local key=object:GetFullName()
    if not held[key] then held[key]={object=object,original=object.bPauseAnims} end
    object.bPauseAnims=true
   end
  end
 end)
 if not ok then release();print('[PhotoFace pose] '..tostring(err)..'\n') end
end)
