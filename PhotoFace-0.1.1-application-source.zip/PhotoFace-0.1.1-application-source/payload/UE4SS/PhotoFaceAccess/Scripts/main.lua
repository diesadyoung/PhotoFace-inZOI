-- PhotoFace object discovery. No writes to game objects.
local source=debug.getinfo(1,'S').source:gsub('^@',''):gsub('\\','/')
local base=assert(source:match('^(.*)/Scripts/[^/]+$'))
local bridge=base..'/bridge/'
local last=''
local function write(key,value)
 local f=assert(io.open(bridge..key..'.cfg','w'));f:write(value);f:close()
end
local function discover()
 local actors=FindAllOf('B1AppearanceCharacter') or {}
 local candidates={}
 for _,actor in ipairs(actors) do
  if actor:IsValid() then
   local component=actor.AppearanceComponent
   if component and component:IsValid() then candidates[#candidates+1]=component end
  end
 end
 if #candidates~=1 then write('discovery_status','Expected one editor character; found '..#candidates);return end
 local full=candidates[1]:GetFullName()
 local path=assert(full:match('^[^ ]+ (.+)$'))
 write('target_path',path)
 write('discovery_status','Editor appearance component found')
 print('[PhotoFace] Editor appearance component found\n')
end
LoopInGameThreadWithDelay(500,function()
 local f=io.open(bridge..'discover_request.cfg','r')
 if not f then return end
 local request=f:read('*a');f:close()
 if request==last then return end
 last=request
 local ok,err=pcall(discover)
 if not ok then write('discovery_status',tostring(err)) end
end)
dofile(base..'/Scripts/frontend-panel.lua')
dofile(base..'/Scripts/frontend-native-input.lua')
dofile(base..'/Scripts/fit-pose.lua')

dofile(base..'/Scripts/runtime-bootstrap.lua')

dofile(base..'/Scripts/fit-view.lua')
