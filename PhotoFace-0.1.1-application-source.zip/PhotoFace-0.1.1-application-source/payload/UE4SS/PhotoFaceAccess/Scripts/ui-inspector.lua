-- Read-only inspection of the frontend UI objects. Runs on the game thread.
local source=debug.getinfo(1,'S').source:gsub('^@',''):gsub('\\','/')
local base=assert(source:match('^(.*)/Scripts/[^/]+$'))
local bridge=base..'/bridge/'
local last=''
local function inspect()
 local rows={os.date('!%Y-%m-%dT%H:%M:%SZ')}
 for _,s in ipairs(FindAllOf('ScriptStruct') or {}) do
  if s:GetFName():ToString()=='B1CohtmlMouseInputRoutingOptions' then
   rows[#rows+1]='ROUTESTRUCT '..s:GetFullName()
   s:ForEachProperty(function(p)
    local key=p:GetFName():ToString()
    for _,view in ipairs(FindAllOf('B1UIModView') or {}) do
     local options=view.CohtmlWidget.ManualMouseInputRoutingOptions
     rows[#rows+1]='ROUTEOPTION '..key..' = '..tostring(options[key])
    end
   end)
  end
 end
 for _,name in ipairs({'B1RootWidget','B1UIManager','CohtmlInputActor','B1CharacterCustomizationWidget','B1UIModManager','B1UIModView','B1UIModOverlayWidget','CohtmlWidget','CohtmlSystem','CohtmlBaseComponent'}) do
  local objects=FindAllOf(name) or {}
  rows[#rows+1]='CLASS '..name..' COUNT '..#objects
  for i,obj in ipairs(objects) do
   if i<=12 and obj:IsValid() then
    rows[#rows+1]='OBJECT '..obj:GetFullName()
    if name=='CohtmlWidget' then rows[#rows+1]='COHTMLCLASS '..obj:GetClass():GetFullName() end
    if name=='B1RootWidget' then
     local ok,root=pcall(function() return obj.WidgetTree.RootWidget end)
     if ok and root and root:IsValid() then
      rows[#rows+1]='ROOT '..root:GetFullName()
      for j=0,root:GetChildrenCount()-1 do rows[#rows+1]='ROOTCHILD '..root:GetChildAt(j):GetFullName() end
     end
    end
    for _,method in ipairs({'IsInViewport','GetVisibility','IsReadyToCreateView','IsReadyForBindings','HasRequestedView'}) do
     local ok,val=pcall(function() return obj[method](obj) end)
     if ok then rows[#rows+1]='STATUS '..method..' = '..tostring(val) end
    end
    if name=='CohtmlWidget' then local ok,val=pcall(function() return obj.URL:ToString() end);if ok then rows[#rows+1]='URL '..val end end
    if name=='B1UIModView' then
     rows[#rows+1]='MODID '..obj.modId:ToString()
     local node=obj.CohtmlWidget
     for _=1,10 do
      if not node or not node:IsValid() then break end
      rows[#rows+1]='ANCESTOR '..node:GetFullName()..' visibility='..tostring(node:GetVisibility())..' enabled='..tostring(node:GetIsEnabled())
      node=node:GetParent()
     end
    end
    local c=obj:GetClass()
    local depth=0
    while c:IsValid() and depth<3 do
     c:ForEachProperty(function(p)
      local key=p:GetFName():ToString()
      local ok,val=pcall(function() return obj[key] end)
      rows[#rows+1]='PROPERTY '..key..' = '..(ok and tostring(val) or '[unreadable]')
      if key=='ManualMouseInputRoutingOptions' then
       p:GetStruct():ForEachProperty(function(field)
        local k=field:GetFName():ToString()
        rows[#rows+1]='ROUTEOPTION '..k..' = '..tostring(obj[key][k])
       end)
      end
     end)
     c:ForEachFunction(function(f) rows[#rows+1]='FUNCTION '..f:GetFName():ToString() end)
     c=c:GetSuperStruct();depth=depth+1
    end
   end
  end
 end
 local f=assert(io.open(bridge..'ui_inspection.txt','w'));f:write(table.concat(rows,'\n'));f:close()
end
LoopInGameThreadWithDelay(500,function()
 local f=io.open(bridge..'ui_request.cfg','r');if not f then return end
 local req=f:read('*a');f:close()
 if req==last then return end
 last=req
 if req:match('^attach') then
  for _,view in ipairs(FindAllOf('B1UIModView') or {}) do
   if view:IsValid() then
    local w=view.ContainerWidget
    if w and w:IsValid() then
     if not w:IsInViewport() then w:AddToViewport(10000) end
     w:SetVisibility(4)
     view.CohtmlWidget:SetVisibility(0)
    end
   end
  end
 end
 local ok,err=pcall(inspect)
 if not ok then local out=io.open(bridge..'ui_error.txt','w');if out then out:write(tostring(err));out:close() end end
end)



