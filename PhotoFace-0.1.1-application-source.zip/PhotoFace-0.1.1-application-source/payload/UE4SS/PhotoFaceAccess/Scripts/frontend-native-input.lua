-- Native hit targets track the collapsed/expanded PhotoFace presentation.
local source=debug.getinfo(1,'S').source:gsub('^@',''):gsub('\\','/')
local bridge=assert(source:match('^(.*)/Scripts/[^/]+$'))..'/bridge/'
local actions,built,buttons={},{},{}
local serial=0
local function read(key)
 local f=io.open(bridge..key..'.cfg','r');if not f then return '' end
 local v=f:read('*a');f:close();return v
end
local function write(key,v)
 local f=assert(io.open(bridge..key..'.cfg','w'));f:write(v);f:close()
end
local buttonClass=StaticFindObject('/Script/UMG.Button')
RegisterHook('/Script/UMG.Widget:ForceLayoutPrepass',function(context)
 local action=actions[context:get():GetFullName()]
 if not action then return end
 if action=='toggle' then write('panel_open',read('panel_open')=='1' and '0' or '1');return end
 if action=='minimize' then write('panel_open','0');return end
 if action=='language' then write('language_menu',read('language_menu')=='1' and '0' or '1');return end
 if action:match('^locale_') then write('ui_language',action:sub(8));write('language_menu','0');return end
 serial=serial+1;write('photo_request',action..'_native_'..os.time()..'_'..serial)
end)
local specs={{'toggle',24,420,56,56},{'minimize',398,492,32,32},{'language',334,492,56,32},
 {'pick',44,600,380,40},{'fit',44,647,380,40},{'undo',44,694,380,40}}
local locales={'auto','en-US','ru-RU','de-DE','fr-FR','es-ES','it-IT','pt-BR','pt-PT','pl-PL','tr-TR','nl-NL','ja-JP','ko-KR','zh-CN','zh-TW'}
for i,id in ipairs(locales) do specs[#specs+1]={'locale_'..id,44+((i-1)%4)*96,544+math.floor((i-1)/4)*43,88,36} end
LoopInGameThreadWithDelay(150,function()
 local ok,err=pcall(function()
  for _,view in ipairs(FindAllOf('B1UIModView') or {}) do
   if view:IsValid() and view.modId:ToString()=='PhotoFace_9CYVRD/FaceProbe' then
    local w=view.ContainerWidget
    if w and w:IsValid() and not built[w:GetFullName()] then
     local tree=w.WidgetTree;local root=tree.RootWidget
     if root and root:IsValid() then
      root:SetVisibility(4)
      for i=root:GetChildrenCount()-1,0,-1 do
       local child=root:GetChildAt(i)
       if child:GetFName():ToString():match('^PhotoFaceNative_') then child:RemoveFromParent() end
      end
      for _,spec in ipairs(specs) do
       local b=StaticConstructObject(buttonClass,tree,FName('PhotoFaceNative_'..spec[1]..'_'..os.time()))
       assert(b and b:IsValid(),'Could not create native button')
       b:SetBackgroundColor({R=0,G=0,B=0,A=0})
       local slot=root:AddChildToCanvas(b);slot:SetPosition({X=spec[2],Y=spec[3]});slot:SetSize({X=spec[4],Y=spec[5]});slot:SetZOrder(100)
       b.OnClicked:Add(b,'ForceLayoutPrepass');actions[b:GetFullName()]=spec[1]
       buttons[#buttons+1]={object=b,action=spec[1]}
      end
      built[w:GetFullName()]=true
     end
    end
   end
  end
  local opened=read('panel_open')=='1';local busy=read('photo_busy'):match('1')~=nil;local languageMenu=read('language_menu')=='1'
  for _,entry in ipairs(buttons) do
   if entry.object:IsValid() then
    local header=entry.action=='toggle' or entry.action=='minimize' or entry.action=='language'
    local choice=entry.action:match('^locale_')~=nil
    local visible=entry.action=='toggle' or (opened and (header or (choice==languageMenu)))
    entry.object:SetVisibility(visible and 0 or 1)
    entry.object:SetIsEnabled(header or choice or entry.action=='undo' or not busy)
   end
  end
 end)
 if not ok then print('[PhotoFace native input] '..tostring(err)..'\n') end
end)
