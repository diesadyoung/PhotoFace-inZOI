"""Visible shape measurements for native inZOI sliders; no texture projection."""
from pathlib import Path
import os, sys, io, json, hashlib, zipfile
DEPS=Path(os.environ.get('PHOTOFACE_DEPS',str(Path(__file__).with_name('face-deps'))))
sys.path.insert(0,str(DEPS))
sys.path.insert(0,str(Path(__file__).with_name('face-deps')))
import numpy as np
from PIL import Image,ImageOps
IMAGE_FORMATS=['JPEG','PNG','WEBP']
try:
    from pillow_heif import register_heif_opener
    register_heif_opener(thumbnails=False)
    IMAGE_FORMATS.append('HEIF')
except ImportError:
    pass
import mediapipe as mp

# Silhouette, brows, eye corners/lids, nose and lips. Iris and expression-sensitive
# mouth interior are deliberately omitted. FaceLandmarker does not measure ears.
LANDMARKS=[10,109,67,103,54,21,162,127,234,93,132,58,172,136,150,149,176,148,152,
 377,400,378,379,365,397,288,361,323,454,356,389,251,284,332,297,338,
 70,63,105,66,107,336,296,334,293,300,
 33,160,159,158,133,153,145,144,263,387,386,385,362,380,374,373,
 168,6,197,195,5,4,1,2,98,97,327,326,
 61,40,37,0,267,270,291,321,314,17,84,91]

def measure_landmarks(points):
    p=np.asarray(points,dtype=float)
    horizontal=p[263,:2]-p[33,:2]
    eye_width=np.linalg.norm(horizontal)
    if eye_width<1e-8:raise ValueError('Degenerate eye axis')
    x=horizontal/eye_width;y=np.array([-x[1],x[0]])
    origin=(p[33,:2]+p[263,:2])/2
    width=np.linalg.norm(p[454,:2]-p[234,:2])
    if width<1e-8:raise ValueError('Degenerate face width')
    q=(p[LANDMARKS,:2]-origin)@np.stack([x,y],axis=1)/width
    return q.reshape(-1)

def feature_weights():
    weights=np.ones((len(LANDMARKS),2))
    for i,index in enumerate(LANDMARKS):
        if index in (160,159,158,153,145,144,387,386,385,380,374,373):weights[i]*=.30
        if index in (40,37,0,267,270,321,314,17,84,91):weights[i]*=.65
    return weights.reshape(-1)

class Analyzer:
    def __init__(self):
        model=Path(__file__).with_name('face_landmarker.task')
        if model.exists():
            model_bytes=model.read_bytes()
        else:
            folder=Path(__file__).with_name('models')
            manifest=json.loads((folder/'manifest.json').read_text(encoding='utf-8'))
            buffer=io.BytesIO()
            with zipfile.ZipFile(buffer,'w',zipfile.ZIP_STORED) as bundle:
                for name,digest in manifest['members'].items():
                    if Path(name).name!=name:raise ValueError('Invalid model member name')
                    raw=(folder/name).read_bytes()
                    if hashlib.sha256(raw).hexdigest()!=digest:raise ValueError('Model checksum mismatch')
                    bundle.writestr(name,raw)
            model_bytes=buffer.getvalue()
        self.model=mp.tasks.vision.FaceLandmarker.create_from_options(mp.tasks.vision.FaceLandmarkerOptions(
            base_options=mp.tasks.BaseOptions(model_asset_buffer=model_bytes),
            running_mode=mp.tasks.vision.RunningMode.IMAGE,num_faces=2,
            output_facial_transformation_matrixes=True,
            min_face_detection_confidence=.45,min_face_presence_confidence=.45))
    def analyze(self,path,game=False,require_frontal=True):
        im=ImageOps.exif_transpose(Image.open(path,formats=IMAGE_FORMATS)).convert('RGB')
        if game:
            w,h=im.size;im=im.crop((int(w*.29),0,int(w*.70),int(h*.78)))
        im.thumbnail((1600,1600))
        result=self.model.detect(mp.Image(image_format=mp.ImageFormat.SRGB,data=np.asarray(im)))
        if len(result.face_landmarks)!=1:raise ValueError('Нужно одно хорошо видимое лицо; найдено: '+str(len(result.face_landmarks)))
        points=np.array([[p.x*im.width,p.y*im.height,p.z*im.width] for p in result.face_landmarks[0]])
        width=float(np.linalg.norm(points[234,:2]-points[454,:2]))
        if width<90:raise ValueError('Лицо слишком мелкое. Приблизь его или выбери более крупное фото.')
        rotation=np.asarray(result.facial_transformation_matrixes[0])[:3,:3]
        rotation=rotation/np.linalg.norm(rotation,axis=0)
        yaw=float(np.degrees(np.arctan2(rotation[0,2],rotation[2,2])))
        pitch=float(np.degrees(np.arctan2(-rotation[1,2],np.hypot(rotation[0,2],rotation[2,2]))))
        if require_frontal and (abs(yaw)>18 or abs(pitch)>20):
            raise ValueError('Для этого этапа нужен анфас: поворот %.0f°, наклон %.0f°.'%(yaw,pitch))
        mouth_open=float(np.linalg.norm(points[13,:2]-points[14,:2])/width)
        if require_frontal and mouth_open>.055:raise ValueError('Выбери фото с закрытым ртом и спокойным выражением.')
        features=measure_landmarks(points)
        return features,{'landmarks':len(points),'face_width_pixels':width,'yaw_degrees':yaw,
            'pitch_degrees':pitch,'mouth_open_ratio':mouth_open,'measurements':features.tolist()}
