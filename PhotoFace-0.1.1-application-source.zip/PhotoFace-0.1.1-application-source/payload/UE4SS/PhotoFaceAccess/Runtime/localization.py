"""Shared local catalogs for the worker and isolated file picker."""
import json,re
from pathlib import Path
CATALOG=json.loads(Path(__file__).with_name('locales.json').read_text(encoding='utf-8'))
def resolve(locale):
 if locale in CATALOG:return locale
 prefix=str(locale).split('-')[0].lower()
 return next((key for key in CATALOG if key.split('-')[0]==prefix),'en-US')
def active(bridge):
 def read(key):
  try:return (bridge/(key+'.cfg')).read_text(encoding='utf-8-sig').strip()
  except OSError:return ''
 requested=read('ui_language')
 return resolve(read('game_language') if requested in ('','auto') else requested)
def translate(locale,key,**params):return CATALOG[resolve(locale)].get(key,CATALOG['en-US'].get(key,key)).format(**params)
def event(text):
 params={};key='error'
 if text.startswith('Готово ракурсов:'):
  m=re.search(r'(\d+) из (\d+)',text);key='selected';params={'used':m[1],'total':m[2]} if m else {'used':'?','total':'?'}
  m=re.search(r'Пропущено: (.*?)(?:\. Желательно|\.\n|\.$)',text,re.S)
  if m:params['files']=m[1]
  params['other_side']='Желательно' in text
 elif text.startswith('Подбор формы:'):
  m=re.search(r'(\d+) / (\d+)',text);key='fitting';params={'current':m[1],'total':m[2]} if m else {'current':'?','total':'?'}
 elif text.startswith(('Настройки формы применены','Готово:')):key='applied'
 elif text.startswith(('Заметного улучшения','Подбор не дал')):key='unchanged'
 elif text.startswith(('Исходное лицо','Подбор отменён')):key='restored'
 elif text.startswith('Выбор отменён'):key='cancelled'
 elif text.startswith('Выбери 3–5 фото в открывшемся'):key='selecting'
 elif text.startswith(('Проверяю фотограф','Анализирую фотограф')):key='analyzing'
 elif text.startswith(('Настраиваю ракурсы','Проверяю подобранные','Измеряю исходное')):key='checking'
 elif text.startswith(('PhotoFace готов','Сначала выбери','Предыдущие фото')):key='ready'
 return {'key':key,'params':params}
def render(locale,payload):
 p=payload.get('params',{});result=translate(locale,payload['key'],**p)
 if p.get('files'):result+='\n'+translate(locale,'skipped',files=p['files'])
 if p.get('other_side'):result+='\n'+translate(locale,'other_side')
 return result
