"""Rank compatible native shape presets; never copy skin, hair or accessories."""
import json
import numpy as np
def decode_rows(value):
 if isinstance(value,list) and len(value)==1 and isinstance(value[0],str):return json.loads(value[0])
 return value
def candidates(rows,head,original,groups,target,baseline,weights,calibration=None,limit=6):
 allowed=sorted({i for _,indices in groups for i in indices})
 result=[];seen=set()
 for row in decode_rows(rows):
  raw=row.get('faceShapeParameters',[])
  if row.get('baseHeadId')!=head or row.get('hiddenFromUI') or row.get('isLockedItem') or len(raw)!=len(original):continue
  raw=np.asarray(raw,dtype=float)
  if not np.all(np.isfinite(raw)) or np.max(abs(raw))>1.000001:continue
  for factor in (.6,1.):
   v=original.copy();v[allowed]=original[allowed]+np.clip((raw[allowed]-original[allowed])*factor,-.8,.8)
   fingerprint=tuple(np.round(v,5))
   if fingerprint in seen:continue
   seen.add(fingerprint)
   predicted=baseline.copy()
   if calibration is not None:
    J,used=calibration
    if J.shape[0]==len(target):predicted=baseline+J@np.array([np.mean(v[g]-original[g]) for g in used])
   error=float(np.mean(((predicted-target)*weights)**2))
   # Small changes win ties when there is no compatible calibration.
   error+=1e-5*float(np.mean((v-original)**2))
   result.append((error,row.get('_row_name','native'),factor,v))
 return sorted(result,key=lambda r:r[0])[:limit]
