"""Local PhotoFace worker: file chooser, on-device landmarks, calibrated fitting."""
from pathlib import Path
import json,os,sys,time,traceback,hashlib,subprocess
sys.path.insert(0,str(Path(__file__).resolve().parent))
sys.path.insert(0,str(Path(__file__).resolve().parent/'face-deps'))
import numpy as np
from scipy.optimize import lsq_linear
from PIL import Image,ImageOps
from native_measurements import Analyzer,feature_weights
from game_mcp import rpc
from localization import active as active_locale,event as status_event,render as localized_status
from native_seeds import candidates as native_candidates
from shape_quality import detail_weights

MOD=Path(os.environ.get('PHOTOFACE_MOD_ROOT',str(Path.home()/'Documents'/'inZOI'/'Mods'/'InGame'/'PhotoFace_9CYVRD')))
if (Path(__file__).parent/'runtime-config.json').exists():
 MOD=Path(json.loads((Path(__file__).parent/'runtime-config.json').read_text(encoding='utf-8'))['mod_root'])
BRIDGE=MOD/'StudioAccess'
CACHE=Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'.local')))/'PhotoFace'/'cache'/hashlib.sha256(str(Path(__file__).resolve().parent).encode('utf-8')).hexdigest()[:12]
CACHE.mkdir(parents=True,exist_ok=True)
def parameter_groups(context,multiview=False):
 # Calibrate left and right independently; the editor's mirror signs differ
 # between controls, so sharing a guessed sign would distort the fit.
 # Z/protrusion and ears are not identifiable from a frontal image.
 kind='male' if context.split(':')[0]=='3' else 'female'
 rows=read('parameter_map_'+kind).split(';')[1:]
 named={}
 for row in rows:
  index,name,axis,typ=row.split(',')
  if name=='None' or axis not in (('1','2','4') if multiview else ('1','2')) or any(s in name for s in ('Ear','Tongue','Eyelash','Eyesack','UpperMouth','LowerMouth')):continue
  key=name
  named.setdefault(key,[]).append(int(index))
 return list(named.items())

def read(key):
 for attempt in range(8):
  try:return (BRIDGE/(key+'.cfg')).read_text(encoding='utf-8-sig').strip()
  except FileNotFoundError:return ''
  except PermissionError:time.sleep(.02*(attempt+1))
 return ''
def write(key,value):
 p=BRIDGE/(key+'.cfg');tmp=p.with_suffix('.tmp')
 for attempt in range(8):
  try:
   tmp.write_text(str(value),encoding='utf-8');tmp.replace(p);return
  except PermissionError:
   if attempt==7:raise
   time.sleep(.02*(attempt+1))
def call(name,**args):
 r=rpc('tools/call',{'name':name,'arguments':args})['result']
 if r.get('isError'):raise RuntimeError(str(r.get('content')))
 if 'structuredContent' in r:return r['structuredContent']
 texts=[b['text'] for b in r.get('content',[]) if b.get('type')=='text']
 return json.loads(texts[0]) if texts and texts[0].startswith('{') else texts
def status(text,busy=False):
 payload=status_event(text)
 if payload['key']=='error':
  try:(CACHE/'last-error.txt').write_text(text,encoding='utf-8')
  except OSError:pass
 write('photo_status_json',json.dumps(payload,ensure_ascii=False))
 write('photo_status',localized_status(active_locale(BRIDGE),payload))
 write('photo_busy','1' if busy else '0')

class Worker:
 def __init__(self):
  self.analyzer=Analyzer();self.selected=None;self.target=None;self.request='';self.sequence=0
  self.views=[];self.selected_paths=[];self.view_angles=[];self.selection_warnings=[]
  self.last_fit_heartbeat=0
 def command(self,action,vector=None):
  if vector is not None:write('fit_vector',','.join(format(float(x),'.9g') for x in vector))
  self.sequence+=1;req='pf_'+action+'_'+str(time.time_ns())+'_'+str(self.sequence)
  write('studio_request',req)
  until=time.monotonic()+10
  while time.monotonic()<until:
   if read('fit_ack')==req:
    if read('fit_error'):raise RuntimeError(read('fit_error'))
    return
   time.sleep(.08)
  raise TimeoutError('Мост редактора не ответил. Открой создание персонажа и подключи Lua-часть мода.')
 def check_cancel(self):
  if time.monotonic()-self.last_fit_heartbeat>3:
   self.last_fit_heartbeat=time.monotonic();write('service_heartbeat',str(int(time.time())))
  request=read('photo_request')
  if request!=self.request and request.startswith('undo_'):
   self.request=request;raise InterruptedError('Подбор отменён; исходное лицо восстановлено.')
 def view(self,angle):
  write('view_yaw',format(float(angle),'.6g'))
  req='view_'+str(time.time_ns());write('view_request',req)
  until=time.monotonic()+3
  while time.monotonic()<until:
   if read('view_ack')==req:
    if read('view_error'):raise RuntimeError(read('view_error'))
    return
   time.sleep(.05)
  raise TimeoutError('Нужна перезагрузка UE4SS: нажми Ctrl+R в окне игры для включения ракурсов.')
 def raw_capture(self,name='capture',require_frontal=True):
  self.check_cancel()
  shot=call('screenshot_capture',Filename=str(CACHE/(name+'.png')).replace('\\','/'),show_ui=False,unique_suffix=False)
  until=time.monotonic()+12
  while time.monotonic()<until:
   last=call('screenshot_get_last')
   if last.get('saved') and not last.get('pending') and Path(last.get('path',''))==Path(shot['path']):
    f,meta=self.analyzer.analyze(last['path'],game=True,require_frontal=require_frontal)
    return f,meta,last['path']
   time.sleep(.12)
  raise TimeoutError('Игра не записала изображение персонажа. Вернись в окно игры.')
 def prepare_views(self):
  if len(self.views)<=1:return
  try:self._prepare_views()
  finally:self.view(0)
 def _prepare_views(self):
  if len(self.views)<=1:return
  status('Настраиваю ракурсы для сравнения формы…',True)
  self.view(0);time.sleep(.4)
  _,front,_=self.raw_capture('view_front')
  self.view(10);time.sleep(.4)
  _,turned,_=self.raw_capture('view_probe',False)
  slope=(turned['yaw_degrees']-front['yaw_degrees'])/10
  self.view(0)
  if not .45<abs(slope)<1.6:raise ValueError('Редактор не повернул персонажа. Открой режим фокуса и повтори.')
  angles=[]
  for i,v in enumerate(self.views):
   angle=(v['meta']['yaw_degrees']-front['yaw_degrees'])/slope
   for attempt in range(3):
    if abs(angle)>65:raise ValueError('Ракурс слишком большой для текущего режима. Используй повороты до 55°.')
    self.view(angle);time.sleep(.35)
    _,meta,_=self.raw_capture('view_align_'+str(i),False)
    error=v['meta']['yaw_degrees']-meta['yaw_degrees']
    if abs(error)<2.5:break
    angle+=error/slope
   if abs(error)>=2.5:raise ValueError('Не удалось совместить ракурс фото и персонажа.')
   angles.append(angle)
  self.view(0);self.view_angles=angles
 def capture(self,name='capture',start_view=0):
  if len(self.views)<=1:return self.raw_capture(name)
  features=[];metadata=[];paths=[]
  for i,(angle,view) in enumerate(list(zip(self.view_angles,self.views))[start_view:],start=start_view):
   self.check_cancel();self.view(angle);time.sleep(.25)
   f,m,p=self.raw_capture(name+'_view'+str(i),False)
   if abs(m['yaw_degrees']-view['meta']['yaw_degrees'])>4:
    raise ValueError('Положение персонажа изменилось во время подбора. Исходная форма будет восстановлена.')
   features.append(f);metadata.append(m);paths.append(p)
  return np.concatenate(features),{'views':metadata,'paths':paths},paths[0]
 def set_vector(self,v):
  self.check_cancel();write('fit_pose_lease','0')
  self.command('vector',v);time.sleep(.45)
 def select(self,path=None):
  if path is None:
   result_path=CACHE/('picker_'+str(time.time_ns())+'.json')
   initial=self.selected.parent if self.selected else Path.home()/'Pictures'
   proc=subprocess.Popen([sys.executable,str(Path(__file__).with_name('photo_picker.py')),str(result_path),str(initial),active_locale(BRIDGE)],creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
   status('Выбери 3–5 фото в открывшемся окне…',True)
   while proc.poll() is None:
    write('service_heartbeat',str(int(time.time())));time.sleep(.2)
   if not result_path.exists():raise RuntimeError('Окно выбора фото закрылось с ошибкой. Попробуй открыть его ещё раз.')
   picked=json.loads(result_path.read_text(encoding='utf-8'));result_path.unlink()
   if picked.get('error'):raise RuntimeError(picked['error'])
   path=picked.get('paths',[])
  if not path:
   status('Выбор отменён.');return
  paths=[Path(path)] if isinstance(path,(str,Path)) else [Path(p) for p in path]
  self.target=None;self.selected=None;self.views=[];self.selected_paths=[];self.view_angles=[]
  if len(paths)!=1 and not 3<=len(paths)<=5:raise ValueError('Выбери 3–5 фото одновременно. Для быстрого теста допустим один анфас.')
  status('Проверяю фотографии на компьютере…',True)
  views=[];warnings=[];seen=set()
  for p in paths:
   try:digest=hashlib.sha256(p.read_bytes()).hexdigest()
   except OSError as e:
    warnings.append(p.name+': файл недоступен');continue
   if digest in seen:raise ValueError('Один снимок выбран несколько раз. Нужны разные ракурсы.')
   seen.add(digest)
   try:
    f,meta=self.analyzer.analyze(p,require_frontal=len(paths)==1)
    if abs(meta['yaw_degrees'])>60 or abs(meta['pitch_degrees'])>15:raise ValueError('нужен поворот до 60° и небольшой наклон головы')
    if meta['mouth_open_ratio']>.055:raise ValueError('рот должен быть закрыт')
    views.append({'path':p,'features':f,'meta':meta})
   except (ValueError,OSError) as e:warnings.append(p.name+': '+str(e))
  if not views:raise ValueError('Ни один снимок не подходит. '+('; '.join(warnings)))
  views.sort(key=lambda v:abs(v['meta']['yaw_degrees']))
  if abs(views[0]['meta']['yaw_degrees'])>12:raise ValueError('В наборе нужен чёткий анфас с поворотом до 12°.')
  if len(paths)>1 and (len(views)<2 or max(v['meta']['yaw_degrees'] for v in views)-min(v['meta']['yaw_degrees'] for v in views)<15):
   raise ValueError('Не хватает разных ракурсов: нужен анфас и поворот минимум на 15°. '+('; '.join(warnings)))
  self.selected=views[0]['path'];self.selected_paths=paths;self.views=views
  self.target=np.concatenate([v['features'] for v in views]);self.selection_warnings=warnings
  (CACHE/'selected-photos.json').write_text(json.dumps([str(p.resolve()) for p in paths],ensure_ascii=False,indent=2),encoding='utf-8')
  meta={'selected':len(paths),'used':len(views),'views':[{'file':v['path'].name,**v['meta']} for v in views],'warnings':warnings}
  (CACHE/'target-analysis.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
  text='Готово ракурсов: '+str(len(views))+' из '+str(len(paths))+'.'
  if warnings:text+=' Пропущено: '+', '.join(p.split(':')[0] for p in warnings)+'.'
  if len(views)>1 and not (min(v['meta']['yaw_degrees'] for v in views)<-15 and max(v['meta']['yaw_degrees'] for v in views)>15):text+=' Желательно добавить поворот в другую сторону.'
  status(text+'\nБудут изменены только игровые настройки формы.')
 def fit(self):
  if self.target is None:
   status('Сначала выбери фотографию.');return
  phase=call('game_get_state')
  if phase.get('phase')!='character_customize':raise ValueError('Открой редактор создания персонажа.')
  self.request=read('photo_request')
  try:write('game_language',call('gameplay_list_languages')['current'])
  except Exception:pass
  # Rediscover the editor object after changing characters or restarting the game.
  write('discover_request','discover_photo_'+str(time.time_ns()));time.sleep(.7)
  self.command('snapshot')
  original=np.array([float(x) for x in read('face_vector').split(',')])
  if len(original)!=245:raise ValueError('Эта версия параметров лица не поддерживается.')
  context=read('face_context')
  base_head=read('face_base_head');skin_id=read('face_skin_id')
  original_slim=float(read('face_skinny_ratio')) if read('face_skinny_ratio') else None
  if not base_head or base_head.startswith('PhotoFace') or skin_id.startswith('PhotoFace'):
   raise ValueError('Сначала выбери обычный шаблон лица и обычную кожу inZOI. Экспериментальная голова с фототекстурой для этого режима не подходит.')
  groups=parameter_groups(context,len(self.views)>1)
  if not groups:raise ValueError('Карта настроек лица не найдена. Нужна калибровка для этой версии игры.')
  self.prepare_views()
  status('Измеряю исходное лицо…',True)
  before,_,before_path=self.capture('before')
  # Mouth opening/blinks are expressions, not identity; reduce their influence.
  weight_profile='detail-balanced-v1' if read('fit_detail_profile')=='1' else 'legacy'
  measurement_weights=detail_weights() if weight_profile=='detail-balanced-v1' else feature_weights()
  weights=np.tile(measurement_weights,max(1,len(self.views)))/np.sqrt(max(1,len(self.views)))
  score=lambda f:float(np.sqrt(np.mean(((f-self.target)*weights)**2)))
  score_before=score(before)
  # Pausing SkeletalMesh animation also prevents native shape controls from
  # reaching the rendered face. Keep the normal editor animation update alive.
  self.command('begin');write('fit_pose_lease','0')
  committed=False
  try:
   time.sleep(.5)
   self.set_vector(original)
   baseline,_,_=self.capture('baseline')
   reference=baseline.copy();anchor=original.copy();seed_name=None
   per_view=lambda f:np.array([float(np.sqrt(np.mean(((a-b)*feature_weights())**2))) for a,b in zip(np.asarray(f).reshape(-1,172),self.target.reshape(-1,172))])
   baseline_view_scores=per_view(baseline)
   acceptable=lambda f:bool(np.all(per_view(f)<=baseline_view_scores*1.025+1e-5))
   # Native preset vectors provide distant starting points without replacing a
   # mesh or any cosmetic. Only the measured controls of this exact head qualify.
   preset_file=CACHE/'native-presets.json'
   try:
    if not preset_file.exists():preset_file.write_text(json.dumps(call('data_table_get_all',Alias='AppearanceFacePreset')),encoding='utf-8')
    rows=json.loads(preset_file.read_text(encoding='utf-8'));calibration=None
    if (CACHE/'last-calibration.npz').exists():
     with np.load(CACHE/'last-calibration.npz') as prior:
      if str(prior['base_head'])==base_head and str(prior['context'])==context:
       calibration=(prior['jacobian'].copy(),prior['groups'].copy())
    choices=native_candidates(rows,base_head,original,groups,self.target,baseline,weights,calibration)
   except (ValueError,KeyError,OSError,RuntimeError):choices=[]
   if read('native_seed_search')!='1':choices=[]
   for _,name,factor,v in choices:
    status('Проверяю подобранные базовые формы…',True)
    self.set_vector(v)
    try:f,_,_=self.capture()
    except ValueError:
     self.set_vector(anchor);continue
    if acceptable(f) and score(f)<score(baseline)*.995:
     anchor=v.copy();baseline=f.copy();seed_name=name+':'+str(factor)
   self.set_vector(anchor)
   best_slim=original_slim
   if original_slim is not None and read('native_seed_search')=='1':
    for slim in (0.,.25,.5,.75,1.):
     if abs(slim-original_slim)<.01:continue
     status('Проверяю подобранные пропорции…',True)
     write('fit_skinny',str(slim));self.command('skinny');time.sleep(.35)
     try:f,_,_=self.capture()
     except ValueError:
      write('fit_skinny',str(best_slim));self.command('skinny');continue
     if acceptable(f) and score(f)<score(baseline)*.98:
      best_slim=slim;baseline=f.copy()
    write('fit_skinny',str(best_slim));self.command('skinny')
   cached_views=0;cached_columns={}
   seed_path=CACHE/'last-calibration.npz'
   if seed_path.exists() and len(self.views)>1:
    try:
     with np.load(seed_path) as seed:
      n=len(seed['view_yaws']);yaws=np.array([v['meta']['yaw_degrees'] for v in self.views])
      if (0<n<len(self.views) and str(seed['base_head'])==base_head and str(seed['context'])==context
          and str(seed['skin_id'])==skin_id and np.max(np.abs(seed['original']-anchor))<1e-6
          and abs(float(seed['face_skinny_ratio'])-float(best_slim if best_slim is not None else 0.))<1e-6
          and np.max(np.abs(seed['view_yaws']-yaws[:n]))<.15
          and np.sqrt(np.mean((seed['baseline']-baseline[:172*n])**2))<.002):
       cached_views=n
       cached_columns={tuple(g):seed['jacobian'][:,i].copy() for i,g in enumerate(seed['groups'])}
    except (KeyError,ValueError,OSError):pass
   columns=[];used=[];resume_count=0
   checkpoint=CACHE/'calibration-partial.npz';layout=json.dumps(groups)
   if checkpoint.exists():
    try:
     with np.load(checkpoint) as cp:
      if (str(cp['head'])==base_head and str(cp['skin'])==skin_id and str(cp['context'])==context and str(cp['layout'])==layout
          and abs(float(cp['slim'])-float(best_slim or 0.))<1e-6
          and np.max(abs(cp['anchor']-anchor))<1e-6
          and cp['target'].shape==self.target.shape and np.max(abs(cp['target']-self.target))<1e-6
          and cp['baseline'].shape==baseline.shape and np.sqrt(np.mean((cp['baseline']-baseline)**2))<.002):
       resume_count=int(cp['completed']);used=cp['groups'].tolist();columns=list(cp['columns'])
    except Exception:pass
   for j,(label,indices) in enumerate(groups):
    if j<resume_count:continue
    self.check_cancel();status('Подбор формы: '+str(j+1)+' / '+str(len(groups))+'\nПока не меняй лицо в редакторе.',True)
    probe=anchor.copy();step=.35
    if max(anchor[indices])>.6:step=-.35
    if min(anchor[indices])<-.6:step=.35
    if np.any(anchor[indices]+step>1) or np.any(anchor[indices]+step< -1):continue
    probe[indices]+=step
    self.set_vector(probe)
    start=cached_views if tuple(indices) in cached_columns else 0
    try:f,_,_=self.capture(start_view=start)
    except ValueError:
     self.set_vector(anchor);continue
    column=(f-baseline[start*172:])/step
    if start:column=np.r_[cached_columns[tuple(indices)],column]
    if .002<np.linalg.norm(column)<3:
     used.append(indices);columns.append(column)
    if (j+1)%10==0 or j==len(groups)-1:
     temp_checkpoint=CACHE/'calibration-partial-writing.npz'
     np.savez(temp_checkpoint,head=base_head,skin=skin_id,context=context,layout=layout,slim=best_slim if best_slim is not None else 0.,
              anchor=anchor,target=self.target,baseline=baseline,completed=j+1,groups=np.asarray(used),columns=np.asarray(columns))
     temp_checkpoint.replace(checkpoint)
   self.set_vector(anchor)
   if not columns:raise RuntimeError('Не удалось измерить влияние настроек на лицо.')
   J=np.array(columns).T
   np.savez(CACHE/'last-calibration.npz',jacobian=J,groups=np.asarray(used),original=anchor,
            baseline=baseline,target=self.target,base_head=base_head,context=context,skin_id=skin_id,
            view_yaws=np.array([v['meta']['yaw_degrees'] for v in self.views]))
   # The fullness scalar is not part of the 245-element morph vector.
   with np.load(CACHE/'last-calibration.npz') as saved:calibration_data={k:saved[k].copy() for k in saved.files}
   calibration_data['face_skinny_ratio']=np.asarray(best_slim if best_slim is not None else 0.)
   np.savez(CACHE/'last-calibration.npz',**calibration_data)
   low=np.array([max(-.3,max(-1-anchor[g])) for g in used]);high=np.array([min(.3,min(1-anchor[g])) for g in used])
   # Regularize a bounded step; all resulting values remain native editable controls.
   regularization=.12 if len(self.views)>1 else .16
   design=np.vstack([J*weights[:,None],np.eye(len(used))*regularization])
   rhs=np.r_[(self.target-baseline)*weights,np.zeros(len(used))]
   delta=lsq_linear(design,rhs,bounds=(low,high),max_iter=100).x
   best=anchor.copy();best_features=baseline;best_score=score(baseline)
   for factor in (1.,.65,.35):
    status('Проверяю подобранные пропорции…',True)
    v=anchor.copy()
    for g,d in zip(used,delta):v[g]=anchor[g]+d*factor
    self.set_vector(v);f,_,_=self.capture()
    if score(f)<best_score and acceptable(f):
     best,best_features,best_score=v.copy(),f.copy(),score(f)
   # One local correction using the measured Jacobian, accepted only if better.
   if best_score<score(baseline):
    correction=np.linalg.lstsq(design,np.r_[(self.target-best_features)*weights,np.zeros(len(used))],rcond=None)[0]
    candidate=best.copy()
    for g,d,lo,hi in zip(used,correction,low,high):candidate[g]=np.clip(best[g]+np.clip(d,-.15,.15),anchor[g]+lo,anchor[g]+hi)
    self.set_vector(candidate);f,_,_=self.capture()
    if score(f)<best_score and acceptable(f):best,best_features,best_score=candidate.copy(),f.copy(),score(f)
   self.set_vector(best)
   after,_,after_path=self.capture('after')
   # The final capture, not an earlier candidate, decides whether to keep edits.
   if score(after)>=score(reference)*.995 or not acceptable(after):
    self.command('rollback');committed=True
    status('Заметного улучшения не получилось; исходные настройки восстановлены.')
    (CACHE/'last-rejected-fit.json').write_text(json.dumps({'baseline_error':score(reference),'final_error':score(after),'base_head':base_head}),encoding='utf-8')
    return
   self.command('commit');committed=True
   final_score=score(after)
   improvement=(score(reference)-final_score)/max(score(reference),1e-8)*100
   report={'mode':'native_multiview_sliders' if len(self.views)>1 else 'native_sliders','measurement_profile':weight_profile,'per_view_guard_profile':'legacy','photo':self.selected.name,'photos':[p.name for p in self.selected_paths],'views_used':len(self.views),'view_yaws':[v['meta']['yaw_degrees'] for v in self.views],'skipped_photos':self.selection_warnings,'context':context,'base_head':base_head,'skin_id':skin_id,'parameter_groups_measured':used,
     'original':original.tolist(),'applied':best.tolist(),'baseline_measurements':reference.tolist(),'native_seed':seed_name,'calibration_anchor':anchor.tolist(),
     'original_face_skinny_ratio':original_slim,'applied_face_skinny_ratio':best_slim,
     'target_measurements':self.target.tolist(),'after_measurements':after.tolist(),
     'weighted_error_before':score(reference),'weighted_error_after':final_score,'regularization':regularization,'maximum_local_step':.3,'maximum_seed_step':.8,'cached_calibration_views':cached_views,
     'per_view_error_before':baseline_view_scores.tolist(),'per_view_error_after':per_view(after).tolist(),
     'measured_ratio_error_reduction_percent':improvement,'before_image':before_path,'after_image':after_path,
     'limitations':['Rendered multi-view landmark fitting; not an identity similarity score','No skin, hair, texture or face-preset replacement','Strict profile 90 degrees and ears unsupported']}
   (CACHE/'last-fit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
   if improvement>1:
    status('Настройки формы применены. Можно продолжить редактирование в игре или отменить подбор.\nУлучшение измерений: '+str(round(improvement))+'%; это не оценка сходства.')
   else:
    status('Подбор не дал заметного улучшения. Исходные параметры сохранены. Попробуй более близкий шаблон лица и фото анфас.')
  finally:
   if len(self.views)>1:
    try:self.view(0)
    except Exception:pass
   try:
    if not committed:self.command('rollback')
   finally:
    write('fit_pose_lease','0');write('photo_busy','0')
 def undo(self):
  self.command('undo');status('Исходное лицо восстановлено.')
 def run(self):
  import msvcrt
  singleton=open(CACHE/'worker.lock','a+b');singleton.seek(0);singleton.write(b'1');singleton.flush();singleton.seek(0)
  try:msvcrt.locking(singleton.fileno(),msvcrt.LK_NBLCK,1)
  except OSError:return
  self.request=read('photo_request')
  status('PhotoFace готов. Выбери 3–5 фотографий.');write('service_ready','1')
  saved_selection=CACHE/'selected-photos.json'
  if saved_selection.exists():
   try:self.select(json.loads(saved_selection.read_text(encoding='utf-8')))
   except Exception:status('Предыдущие фото недоступны. Выбери 3–5 фотографий заново.')
  attached=False;last_heartbeat=0;last_language=0
  while True:
   if time.monotonic()-last_language>10:
    last_language=time.monotonic()
    try:write('game_language',call('gameplay_list_languages')['current'])
    except Exception:pass
   if time.monotonic()-last_heartbeat>3:
    last_heartbeat=time.monotonic();write('service_heartbeat',str(int(time.time())))
    try:
     phase=call('game_get_state')
     if not attached and phase.get('phase') not in ('boot','loading','unknown'):
      listing=str(call('uimod_list'))
      if 'PhotoFace_9CYVRD/FaceProbe' not in listing:call('uimod_mount',mod_id='PhotoFace_9CYVRD')
      try:self.command('ping')
      except (TimeoutError,RuntimeError):call('luamod_mount',mod_id='PhotoFace_9CYVRD')
      attached=True
    except Exception:attached=False
   req=read('photo_request')
   if req and req!=self.request:
    self.request=req
    try:
     if req.startswith('pick_'):self.select()
     elif req.startswith('fit_'):self.fit()
     elif req.startswith('undo_'):self.undo()
    except Exception as e:
     with (CACHE/'worker-errors.log').open('a',encoding='utf-8') as log:
      log.write(time.strftime('%Y-%m-%d %H:%M:%S')+'\n'+traceback.format_exc()+'\n')
     status(str(e));write('fit_pose_lease','0')
   time.sleep(.15)

if __name__=='__main__':
 worker=Worker()
 if len(sys.argv)>1 and sys.argv[1] in ('--fit-photo','--fit-photos'):
  try:worker.select(sys.argv[2] if sys.argv[1]=='--fit-photo' else sys.argv[2:]);worker.fit()
  except Exception as e:status(str(e));raise
 else:worker.run()
