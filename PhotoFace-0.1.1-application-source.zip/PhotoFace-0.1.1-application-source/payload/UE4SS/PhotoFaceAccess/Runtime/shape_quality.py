"""Regional shape diagnostics. These are not identity or likeness percentages."""
import numpy as np
from native_measurements import LANDMARKS,feature_weights
REGIONS={
 'upper_contour':LANDMARKS[:8]+LANDMARKS[29:36],
 'jaw_cheeks':LANDMARKS[8:29],
 'brows':LANDMARKS[36:46],
 'eyes':LANDMARKS[46:62],
 'nose':LANDMARKS[62:74],
 'mouth':LANDMARKS[74:86],
}
def detail_weights():
 legacy=feature_weights();w=legacy.reshape(-1,2).copy()
 gains={'upper_contour':.35,'jaw_cheeks':1.1,'brows':1.1,'eyes':1.4,'nose':1.5,'mouth':1.4}
 for name,ids in REGIONS.items():
  for landmark in ids:w[LANDMARKS.index(landmark)]*=gains[name]
 w=w.reshape(-1)
 return w*np.sqrt(np.mean(legacy**2)/np.mean(w**2))
def region_errors(features,target):
 difference=(np.asarray(features)-np.asarray(target)).reshape(-1,len(LANDMARKS),2)
 return {name:np.sqrt(np.mean(difference[:,[LANDMARKS.index(i) for i in ids],:]**2,axis=(1,2))).tolist() for name,ids in REGIONS.items()}
