"""Isolated UI process: keep Windows file dialogs away from ML/COM initialization."""
import json,sys
from pathlib import Path
from localization import translate,resolve
def main():
 import tkinter as tk
 from tkinter import filedialog
 output=Path(sys.argv[1]);initial=Path(sys.argv[2]) if len(sys.argv)>2 else Path.home()/'Pictures'
 locale=resolve(sys.argv[3] if len(sys.argv)>3 else 'en-US')
 root=tk.Tk();root.title('PhotoFace')
 root.geometry('440x100');root.resizable(False,False)
 tk.Label(root,text=translate(locale,'intro'),wraplength=410,padx=12,pady=12).pack()
 root.attributes('-topmost',True);root.update()
 try:
  paths=filedialog.askopenfilenames(parent=root,title='PhotoFace · '+translate(locale,'pick'),initialdir=str(initial),filetypes=[(translate(locale,'pick'),'*.jpg *.jpeg *.png *.webp')])
  result={'paths':list(paths)}
 except Exception as e:result={'error':str(e)}
 finally:root.destroy()
 output.write_text(json.dumps(result,ensure_ascii=False),encoding='utf-8')
if __name__=='__main__':main()
