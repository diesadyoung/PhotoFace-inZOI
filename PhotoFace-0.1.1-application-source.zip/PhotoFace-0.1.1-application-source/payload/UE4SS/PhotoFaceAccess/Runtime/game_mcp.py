import json,urllib.request,sys
url='http://127.0.0.1:11212/mcp'
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):
  raise urllib.error.URLError('PhotoFace refuses redirects from the local game API')
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
def rpc(method,params=None):
 data={'jsonrpc':'2.0','id':1,'method':method}
 if params is not None:data['params']=params
 req=urllib.request.Request(url,json.dumps(data).encode(),{'Content-Type':'application/json','Accept':'application/json, text/event-stream'})
 with opener.open(req,timeout=20) as r:
  raw=r.read().decode()
  if raw.startswith('event:') or raw.startswith('data:'):
   return json.loads(next(x[6:] for x in raw.splitlines() if x.startswith('data: ')))
  return json.loads(raw)
if __name__=='__main__':
 method=sys.argv[1] if len(sys.argv)>1 else 'tools/list'
 params=json.loads(sys.argv[2]) if len(sys.argv)>2 else {}
 result=rpc(method,params)
 from pathlib import Path
 Path('work/mcp-last.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 if method=='tools/list':
  ts=result.get('result',{}).get('tools',[])
  print(json.dumps([t for t in ts if any(k in t['name'] for k in ['uimod','face_shape','game_get_state','cli_help','cli_list'])],ensure_ascii=False,indent=2))
 else:print(json.dumps(result,ensure_ascii=False,indent=2))
