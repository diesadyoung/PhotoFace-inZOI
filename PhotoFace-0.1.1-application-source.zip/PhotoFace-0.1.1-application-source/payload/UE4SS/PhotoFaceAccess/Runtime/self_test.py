"""Checks bundled components without changing game parameters."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).parent))
sys.path.insert(0,str(Path(__file__).parent/'face-deps'))
import numpy as np
from scipy.optimize import lsq_linear
from PIL import Image
import tkinter as tk
from native_measurements import Analyzer
assert lsq_linear(np.eye(2),np.ones(2)).success
root=tk.Tk();root.withdraw();root.update();root.destroy()
a=Analyzer();a.model.close()
print('PASS: bundled Python, NumPy, SciPy, Pillow, Tk file picker and MediaPipe model')
if '--game' in sys.argv:
 from game_mcp import rpc
 try:r=rpc('tools/list')['result']['tools']
 except Exception:
  print('FAIL: local game API unavailable. Start inZOI and retry Diagnose.cmd. If the game is running, this game build/API may be unsupported.')
  sys.exit(2)
 names={x['name'] for x in r}
 required={'screenshot_capture','screenshot_get_last','game_get_state','uimod_list','uimod_mount','luamod_mount','gameplay_list_languages','data_table_get_all'}
 missing=required-names
 if missing:raise RuntimeError('Game API is missing: '+', '.join(sorted(missing)))
 print('PASS: localhost game API and required tools (no game changes)')
