Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
CreateObject("WScript.Shell").Run Chr(34) & base & "\Python\pythonw.exe" & Chr(34) & " -I " & Chr(34) & base & "\Runtime\photo_service.py" & Chr(34), 0, False
