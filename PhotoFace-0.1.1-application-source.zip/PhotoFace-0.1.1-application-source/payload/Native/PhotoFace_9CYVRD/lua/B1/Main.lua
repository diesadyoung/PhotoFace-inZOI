-- Editor face access through the supported BlueLua appearance binding.
local M={}
local MOD='PhotoFace_9CYVRD'
local pending,last_request,frames
local fit,photo_backup
local function cfg(key,value)
 local text=tostring(value):gsub('\\','/'):gsub('"','_'):gsub('[\r\n]',' ')
 local ok,msg=inzoi.cli.execute('uimod.cfg_save mod_id='..MOD..' section=StudioAccess key='..key..' value="'..text..'"')
 if not ok then error(msg or 'cfg write failed') end
end
local function load(key)
 local ok,msg,data=inzoi.cli.execute('uimod.cfg_load mod_id='..MOD..' section=StudioAccess key='..key)
 return ok and data and data:match('"value"%s*:%s*"([^"]*)"') or nil
end
local function component()
 local path=load('target_path')
 if not path then error('Run editor discovery first') end
 local comp=LoadObject(path)
 if not comp or not comp:IsValid() then error('Editor component is no longer valid; discover again') end
 return comp,path
end
local function values(array)
 local result={}
 for i=1,array:Length() do result[i]=array:Get(i) end
 return result
end
local function csv(v)
 local out={};for i=1,#v do out[i]=string.format('%.9g',v[i]) end
 return table.concat(out,',')
end
local function set_all(comp,v)
 if not comp:IsValid() then error('Editor character closed') end
 local a=comp.AppearanceSetting.Head.FaceShapeParameters
 if a:Length()~=#v then error('Face layout changed') end
 for i=1,#v do a:Set(i,v[i]) end
 INZOI.UB1AppearanceComponent.RefreshAll(comp)
 for i=1,#v do if math.abs(a:Get(i)-v[i])>0.000002 then error('Face write verification failed') end end
end
local function rollback_fit()
 if fit then
  local saved=fit;fit=nil
  if saved.component:IsValid() and saved.component.AppearanceSetting.Head.BaseHeadId==saved.base_head then
   if saved.original_slim~=nil then saved.component.AppearanceSetting.Head.FaceSkinnyRatio=saved.original_slim end
   set_all(saved.component,saved.original)
  end
 end
end
local function restore()
 if not pending then return end
 local saved=pending
 if not saved.component:IsValid() then error('Editor closed before restore') end
 local array=saved.component.AppearanceSetting.Head.FaceShapeParameters
 array:Set(54,saved.original)
 INZOI.UB1AppearanceComponent.RefreshAll(saved.component)
 local same=array:Length()==#saved.snapshot
 for i=1,array:Length() do if math.abs(array:Get(i)-saved.snapshot[i])>0.000001 then same=false end end
 if not same then error('Parameter comparison after restore failed') end
 pending=nil
 cfg('last_result','PASS: editor param 53 '..string.format('%.7f',saved.original)..' -> 0.8 -> '..string.format('%.7f',array:Get(54))..'; all '..array:Length()..' parameters restored')
end
local function handle()
 local request=load('studio_request')
 if not request or request==last_request then return end
 last_request=request
 if request:match('^pf_') then
  cfg('fit_error','')
  if request:match('^pf_ping') then cfg('fit_ack',request);return end
  local ok,err=pcall(function()
   local comp,path=component()
   local array=comp.AppearanceSetting.Head.FaceShapeParameters
   if request:match('^pf_snapshot') then
    cfg('face_vector',csv(values(array)))
    cfg('face_context',tostring(comp.AppearanceSetting.Gender)..':'..tostring(comp.AppearanceSetting.BodyAgeType))
    cfg('face_base_head',comp.AppearanceSetting.Head.BaseHeadId)
    cfg('face_skin_id',comp.AppearanceSetting.Head.Skin.SkinId)
    cfg('face_skinny_ratio',comp.AppearanceSetting.Head.FaceSkinnyRatio)
    cfg('face_actor_path',path)
   elseif request:match('^pf_begin') then
    if pending or fit then error('Another edit is active') end
    fit={component=comp,path=path,base_head=comp.AppearanceSetting.Head.BaseHeadId,original=values(array),original_slim=comp.AppearanceSetting.Head.FaceSkinnyRatio,deadline=os.time()+30}
    cfg('face_vector',csv(fit.original))
   elseif request:match('^pf_vector') then
    if not fit or fit.path~=path then error('Face fitting session not active') end
    if comp.AppearanceSetting.Head.BaseHeadId~=fit.base_head then error('Base face changed during fitting') end
    local text=load('fit_vector') or ''
    local v={}
    for token in text:gmatch('[^,]+') do
     local n=tonumber(token)
     if not n or n~=n or math.abs(n)>1.000001 then error('Invalid face value') end
     v[#v+1]=n
    end
    if #v~=array:Length() then error('Invalid face parameter count') end
    fit.deadline=os.time()+30
    set_all(comp,v)
    fit.expected=v
   elseif request:match('^pf_skinny') then
    if not fit or fit.path~=path or comp.AppearanceSetting.Head.BaseHeadId~=fit.base_head then error('Face fitting session not active') end
    local n=tonumber(load('fit_skinny') or '')
    if not n or n~=n or n<0 or n>1 then error('Invalid face slim ratio') end
    comp.AppearanceSetting.Head.FaceSkinnyRatio=n
    INZOI.UB1AppearanceComponent.RefreshAll(comp)
    if math.abs(comp.AppearanceSetting.Head.FaceSkinnyRatio-n)>0.000002 then error('Face slim ratio write failed') end
    fit.expected_slim=n;fit.deadline=os.time()+30
   elseif request:match('^pf_commit') then
    if not fit or fit.path~=path then error('Face fitting session not active') end
    if comp.AppearanceSetting.Head.BaseHeadId~=fit.base_head then error('Base face changed before commit') end
    if not fit.expected then error('No fitted vector to commit') end
    for i=1,#fit.expected do
     if math.abs(array:Get(i)-fit.expected[i])>0.000002 then error('Face changed before commit') end
    end
    if math.abs(comp.AppearanceSetting.Head.FaceSkinnyRatio-(fit.expected_slim or fit.original_slim))>0.000002 then error('Face slim ratio changed before commit') end
    photo_backup={component=fit.component,path=fit.path,base_head=fit.base_head,original=fit.original,original_slim=fit.original_slim}
    fit=nil
    cfg('last_result','PhotoFace: photo proportions applied. Undo is available.')
   elseif request:match('^pf_rollback') then
    rollback_fit()
    cfg('last_result','PhotoFace: original face restored')
   elseif request:match('^pf_undo') then
    rollback_fit()
    if not photo_backup or photo_backup.path~=path then error('No photo edit to undo for this character') end
    if photo_backup.base_head~=comp.AppearanceSetting.Head.BaseHeadId then error('Base face changed; undo belongs to the previous head') end
    if photo_backup.original_slim~=nil then comp.AppearanceSetting.Head.FaceSkinnyRatio=photo_backup.original_slim end
    set_all(comp,photo_backup.original);photo_backup=nil
    cfg('last_result','PhotoFace: original face restored')
   else error('Unknown PhotoFace request') end
  end)
  if not ok then
   pcall(rollback_fit)
   cfg('fit_error',tostring(err))
  end
  cfg('fit_ack',request)
  return
 end
 if request:match('^restore') then restore();return end
 if pending and not request:match('^read') then error('Restore previous edit first') end
 local comp,path=component()
 local array=comp.AppearanceSetting.Head.FaceShapeParameters
 if array:Length()<54 then error('Unsupported face parameter layout') end
 if request:match('^map') then
  local asset=comp:GetOuter().CachedFaceDataAsset
  if not asset or not asset:IsValid() then error('Face data asset unavailable') end
  local setting=comp.AppearanceSetting
  if setting.Gender~=2 and setting.Gender~=3 then error('Unsupported gender definition') end
  local male=request:match('^mapmale') or (not request:match('^mapfemale') and setting.Gender==3)
  local source=male and asset.MaleFaceData or asset.FemaleFaceData
  local data=source:Find(setting.BodyAgeType)
  local groups=data.CustomizeGroups
  local rows={'index,name,axis,type'}
  for i=1,groups:Length() do
   local group=groups:Get(i)
   rows[#rows+1]=string.format('%d,%s,%s,%s',i-1,tostring(group.GroupName),tostring(group.GizmoAxis),tostring(group.GizmoType))
  end
  cfg(male and 'parameter_map_male' or 'parameter_map_female',table.concat(rows,';'))
  cfg('last_result','Exported '..groups:Length()..' face parameter definitions')
 elseif request:match('^read') then
  cfg('last_result','Editor head: '..array:Length()..' parameters; param 53 = '..string.format('%.7f',array:Get(54)))
 elseif request:match('^test') or request:match('^hold') then
  local snapshot={}
  for i=1,array:Length() do snapshot[i]=array:Get(i) end
  local seconds=request:match('^hold') and 300 or 3
  pending={component=comp,original=array:Get(54),snapshot=snapshot,deadline=os.time()+seconds}
  array:Set(54,0.8)
  INZOI.UB1AppearanceComponent.RefreshAll(comp)
  if math.abs(array:Get(54)-0.8)>0.000001 then error('Editor parameter write was not confirmed') end
  cfg('last_result','Editor param 53 = 0.8; automatic restore in '..seconds..' seconds')
 end
end
function M.on_begin()
 -- Old on-disk requests are never replayed after remount/startup.
 last_request=load('studio_request')
 cfg('bridge_status','BlueLua editor bridge ready')
end
function M.on_tick(dt)
 if fit and os.time()>=fit.deadline then
  local ok,err=pcall(rollback_fit)
  cfg('last_result',ok and 'PhotoFace: fitting timeout; original face restored' or 'PhotoFace rollback error: '..tostring(err))
 end
 if pending and os.time()>=pending.deadline then
  local ok,err=pcall(restore)
  if not ok then cfg('last_result','RESTORE ERROR: '..tostring(err)) end
 end
 frames=(frames or 0)+1
 if frames%15~=0 then return end
 local ok,err=pcall(handle)
 if not ok then
  local restored,restore_error=pcall(restore)
  cfg('last_result','ERROR: '..tostring(err)..(restored and '' or '; RESTORE ERROR: '..tostring(restore_error)))
 end
end
function M.on_end()
 if fit then pcall(rollback_fit) end
 if pending and pending.component:IsValid() then pcall(restore) end
end
return M
