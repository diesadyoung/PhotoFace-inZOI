-- PhotoFace -- B2 Main (global simulation script)
-- Runs once when the simulation starts; destroyed when it ends.

local M = {}

function M.on_begin()
    print("[PhotoFace] B2 Main initialized")
end

function M.on_end()
    print("[PhotoFace] B2 Main shutdown")
end

return M