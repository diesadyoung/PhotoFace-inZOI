(function(){
 'use strict';
 var root=wf.root,box=wf.content,opened=false,menu=false,locale='en-US',requested='auto',game='en-US',payload={key:'ready',params:{}};
 var catalogs=window.PF_I18N,ids=['auto','en-US','ru-RU','de-DE','fr-FR','es-ES','it-IT','pt-BR','pt-PT','pl-PL','tr-TR','nl-NL','ja-JP','ko-KR','zh-CN','zh-TW'];
 document.getElementById('title-bar').style.display='none';
 var resize=document.getElementById('resize-handle');if(resize)resize.style.display='none';
 box.style.cssText='position:static;padding:0;overflow:visible';
 function t(key,p){var s=(catalogs[locale]||catalogs['en-US'])[key]||key;return s.replace(/\{(\w+)\}/g,function(_,k){return p&&p[k]!=null?p[k]:'';});}
 box.innerHTML='<button id="pf-icon" title="PhotoFace" style="position:absolute;display:flex;align-items:center;justify-content:center;left:0;top:0;width:56px;height:56px;padding:0;margin:0;line-height:0;border-radius:18px;background:#f1f7f7;border:1px solid #b7d8d7">'+
 '<svg style="display:block;flex-shrink:0" width="30" height="30" viewBox="0 0 32 32"><g fill="none" stroke="#28515d" stroke-width="2" stroke-linecap="round"><path d="M10 3H5a2 2 0 0 0-2 2v5M22 3h5a2 2 0 0 1 2 2v5M3 22v5a2 2 0 0 0 2 2h5M29 22v5a2 2 0 0 1-2 2h-5M9 11c0-9 14-9 14 0v6c0 9-14 9-14 0zM12 13h1m6 0h1m-7 7c2 1 4 1 6 0"/></g></svg></button>'+
 '<div id="pf-panel" style="position:absolute;left:0;top:60px;width:420px;height:426px;background:rgba(242,247,249,.97);border:1px solid #d1e1e5;border-radius:20px;color:#263d47;overflow:hidden">'+
 '<b style="position:absolute;left:20px;top:20px;font-size:21px">PhotoFace</b><button id="pf-language" style="position:absolute;left:310px;top:12px;width:56px;height:32px;padding:0;margin:0;border-radius:10px;background:#deebed;color:#28515d;font-size:13px"></button><button style="position:absolute;left:374px;top:12px;width:32px;height:32px;padding:0;margin:0;border:0;border-radius:10px;background:#deebed;color:#28515d">−</button>'+
 '<div id="pf-form"><div id="pf-intro" style="position:absolute;left:20px;top:60px;width:380px;font-size:13px;line-height:18px"></div>'+
 '<button id="pf-pick" style="position:absolute;left:20px;top:120px;width:380px;height:40px;margin:0"></button>'+
 '<button id="pf-fit" style="position:absolute;left:20px;top:167px;width:380px;height:40px;margin:0"></button>'+
 '<button id="pf-undo" style="position:absolute;left:20px;top:214px;width:380px;height:40px;margin:0"></button>'+
 '<div id="pf-status" style="position:absolute;left:20px;top:272px;width:380px;max-height:72px;overflow:hidden;font-size:13px;line-height:18px;white-space:pre-wrap"></div>'+
 '<div id="pf-footer" style="position:absolute;left:20px;top:349px;width:380px;max-height:64px;overflow:hidden;font-size:12px;line-height:16px;color:#59717c"></div></div><div id="pf-languages"></div></div>';
 var grid=document.getElementById('pf-languages');
 ids.forEach(function(id,i){var b=document.createElement('button');b.id='pf-lang-'+id;b.style.cssText='position:absolute;left:'+(20+(i%4)*96)+'px;top:'+(64+Math.floor(i/4)*43)+'px;width:88px;height:36px;padding:2px;margin:0;font-size:12px;line-height:14px;border-radius:8px';grid.appendChild(b);});
 function resolve(id){if(catalogs[id])return id;var prefix=id.split('-')[0];return Object.keys(catalogs).filter(function(k){return k.split('-')[0]===prefix;})[0]||'en-US';}
 function releaseHover(){try{inzoi.view.hover(false);}catch(e){}}
 root.addEventListener('mouseenter',releaseHover);root.addEventListener('mouseleave',releaseHover);
 function render(){
  locale=resolve(requested==='auto'?game:requested);document.documentElement.lang=locale;
  root.style.cssText='position:absolute;display:block;left:24px;top:420px;width:'+(opened?'420':'56')+'px;height:'+(opened?'486':'56')+'px;background:transparent;overflow:visible;font-family:var(--inzoi-font-ui),"Segoe UI","Microsoft YaHei","Yu Gothic","Malgun Gothic",sans-serif;';
  document.getElementById('pf-panel').style.display=opened?'block':'none';document.getElementById('pf-form').style.display=menu?'none':'block';grid.style.display=menu?'block':'none';
  ['intro','pick','fit','undo','footer'].forEach(function(k){document.getElementById('pf-'+k).textContent=t(k);});
  var p=payload.params||{},s=t(payload.key,p);if(p.files)s+='\n'+t('skipped',p);if(p.other_side)s+='\n'+t('other_side');document.getElementById('pf-status').textContent=s;
  var lang=document.getElementById('pf-language');lang.textContent=locale==='zh-CN'?'简中':locale==='zh-TW'?'繁中':locale.slice(0,2).toUpperCase();lang.title=t('language');
  ids.forEach(function(id){document.getElementById('pf-lang-'+id).textContent=id==='auto'?t('auto'):catalogs[id].name;});releaseHover();
 }
 function cfg(key){return wf.cli('uimod.cfg_load',{mod_id:wf.MOD_ID,section:'StudioAccess',key:key}).then(function(r){return r.success&&r.data?r.data.value:'';}).catch(function(){return '';});}
 render();setInterval(function(){cfg('panel_open').then(function(v){if(v==='0'||v==='1')opened=v==='1';render();});cfg('language_menu').then(function(v){if(v==='0'||v==='1')menu=v==='1';render();});cfg('photo_status_json').then(function(v){try{if(v)payload=JSON.parse(v);}catch(e){}render();});},400);
 setInterval(function(){cfg('ui_language').then(function(v){if(v)requested=v;render();});cfg('game_language').then(function(v){if(v)game=v;render();});},1000);
})();
