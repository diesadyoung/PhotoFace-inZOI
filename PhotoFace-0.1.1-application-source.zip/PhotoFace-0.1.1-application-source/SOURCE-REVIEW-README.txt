PhotoFace 0.1.1-alpha — application source and review instructions

This is the readable application source corresponding to the Main File. It is NOT
an installable replacement for the Main File and contains no Python runtime,
compiled dependency binaries or model weights. Original paths are preserved.

PhotoFace has no application EXE compilation stage: its own Python, Lua, HTML and
JavaScript are interpreted directly. Install.cmd invokes the readable Install.ps1.
launch-runtime.vbs starts the bundled Python runtime. Review these entry points,
then Runtime/photo_service.py and Scripts/main.lua.

To reproduce the application portion:
1. Extract the exact PhotoFace-0.1.1-alpha-nexus.zip Main File to a working folder.
2. Overlay payload/ and the root installer/diagnostic scripts from this source
   archive onto that folder, retaining all relative paths.
3. Retain the original Python runtime, face-deps, models, legal notices and other
   third-party files from the Main File. Exact versions are in DEPENDENCIES.json.
4. Package that folder as a standard ZIP with no nested archives or passwords.
   Recalculate hashes after any changes. Do not claim the original Main File hash
   for a modified archive. No compiler or packing/obfuscation tool is used for
   the PhotoFace application code.

This overlay procedure reproduces the application source, not a clean rebuild of
all upstream native binaries. Native third-party components come from upstream
binary distributions. Read LEGAL/MODIFICATIONS.txt for local dependency changes;
the Protobuf upstream security patch is included in LEGAL. The Main File itself
also contains the installed readable dependency .py source files.

PhotoFace-0.1.1-sources.zip is the separate OpenBLAS/GCC corresponding-source
companion, including source origins and build entry points. It does not contain
all upstream projects or promise a bit-for-bit rebuild. Preserve its availability
alongside the binary release. See the included notices for each component's terms.

Review/testing: use a disposable Windows x64 environment, install compatible
UE4SS separately, close inZOI, run Install.cmd, then Diagnose.cmd. No administrator
privileges should be required for a normal writable Steam library. The running
game exposes the local API on 127.0.0.1:11212. Game-closed diagnostics are expected
to report that the API is unavailable. Full testing on a second PC is outstanding.

No personal photos, personal face presets or game binaries are supplied here.
