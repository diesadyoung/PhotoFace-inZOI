[CmdletBinding()]
param([string]$GamePath,[string]$DocumentsPath)
$ErrorActionPreference='Stop'
$createdNative=$false
$createdAccess=$false
try {
 if(Get-Process -Name 'inZOI*','BlueClient*' -ErrorAction SilentlyContinue){throw 'Close inZOI before installing PhotoFace.'}
 if (-not $GamePath) {
  $roots=@()
  $steam=(Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction SilentlyContinue).SteamPath
  if($steam){
   $roots+= $steam
   $vdf=Join-Path $steam 'steamapps\libraryfolders.vdf'
   if(Test-Path -LiteralPath $vdf){
    foreach($m in [regex]::Matches((Get-Content -LiteralPath $vdf -Raw -Encoding UTF8),'"path"\s+"([^"]+)"')){$roots+=$m.Groups[1].Value.Replace('\\','\')}
   }
  }
  foreach($r in ($roots | Select-Object -Unique)){
   $candidate=Join-Path $r 'steamapps\common\inZOI'
   if(Test-Path -LiteralPath (Join-Path $candidate 'BlueClient\Binaries\Win64')){$GamePath=$candidate;break}
  }
  if(-not $GamePath){
   Add-Type -AssemblyName System.Windows.Forms
   $dialog=New-Object System.Windows.Forms.FolderBrowserDialog
   $dialog.Description='Choose the inZOI game folder containing BlueClient'
   if($dialog.ShowDialog() -ne 'OK'){throw 'Installation cancelled.'}
   $GamePath=$dialog.SelectedPath
  }
 }
 $GamePath=(Resolve-Path -LiteralPath $GamePath).Path
 $win64=Join-Path $GamePath 'BlueClient\Binaries\Win64'
 if(-not(Test-Path -LiteralPath $win64)){throw 'Choose the inZOI root folder containing BlueClient.'}
 if(-not(Test-Path -LiteralPath (Join-Path $win64 'ue4ss\UE4SS.dll'))){throw 'Install UE4SS Packaged for inZOI first: https://www.nexusmods.com/inzoi/mods/243'}
 if(-not $DocumentsPath){$DocumentsPath=[Environment]::GetFolderPath('MyDocuments')}
 if(-not $DocumentsPath){throw 'Documents folder unavailable; pass -DocumentsPath.'}
 $native=Join-Path $DocumentsPath 'inZOI\Mods\InGame\PhotoFace_9CYVRD'
 $access=Join-Path $win64 'ue4ss\Mods\PhotoFaceAccess'
 if((Test-Path -LiteralPath $native) -or (Test-Path -LiteralPath $access)){throw 'PhotoFace is already present. Close the game and use Uninstall.cmd from the installed PhotoFaceAccess folder first. Existing files were preserved.'}
 foreach($part in @('payload\Native\PhotoFace_9CYVRD\mod_manifest.json','payload\UE4SS\PhotoFaceAccess\Python\python.exe','payload\UE4SS\PhotoFaceAccess\Runtime\models\manifest.json')){
  if(-not(Test-Path -LiteralPath (Join-Path $PSScriptRoot $part))){throw 'Incomplete archive. Extract the entire ZIP before running Install.cmd.'}
 }
 New-Item -ItemType Directory -Force -Path (Split-Path $native),(Split-Path $access) | Out-Null
 New-Item -ItemType Directory -Path $native | Out-Null
 $createdNative=$true
 Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'payload\Native\PhotoFace_9CYVRD') | Copy-Item -Destination $native -Recurse
 New-Item -ItemType Directory -Path $access | Out-Null
 $createdAccess=$true
 Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'payload\UE4SS\PhotoFaceAccess') | Copy-Item -Destination $access -Recurse
 New-Item -ItemType Directory -Force -Path (Join-Path $native 'StudioAccess') | Out-Null
 New-Item -ItemType Junction -Path (Join-Path $access 'bridge') -Target (Join-Path $native 'StudioAccess') | Out-Null
 $cfg=@{mod_root=$native} | ConvertTo-Json
 [IO.File]::WriteAllText((Join-Path $access 'Runtime\runtime-config.json'),$cfg,(New-Object Text.UTF8Encoding $false))
 foreach($key in @('native_seed_search','fit_detail_profile')){[IO.File]::WriteAllText((Join-Path $native "StudioAccess\$key.cfg"),'1')}
 Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Uninstall.ps1'),(Join-Path $PSScriptRoot 'Uninstall.cmd'),(Join-Path $PSScriptRoot 'Diagnose.cmd') -Destination $access
 [IO.File]::WriteAllText((Join-Path $access 'photoface-install.json'),(@{native=$native;access=$access;version='0.1.1-alpha'} | ConvertTo-Json),(New-Object Text.UTF8Encoding $false))
 & (Join-Path $access 'Python\python.exe') -I (Join-Path $access 'Runtime\self_test.py')
 if($LASTEXITCODE -ne 0){throw 'Installed runtime failed its self-test. Keep the error output for troubleshooting.'}
 Write-Host 'PhotoFace installed. Start inZOI and open Create a Zoi. No Codex, system Python or ModKit is required.'
} catch {
 $installError=$_
 # Only folders created by this run are moved out of the active mod directories.
 # Never delete files and never move an installation that existed before this run.
 foreach($entry in @(@{created=$createdNative;path=$native;leaf='PhotoFace_9CYVRD'},@{created=$createdAccess;path=$access;leaf='PhotoFaceAccess'})){
  if($entry.created -and (Test-Path -LiteralPath $entry.path)){
   try {
    $target=[IO.Path]::GetFullPath($entry.path)
    if((Split-Path $target -Leaf) -ne $entry.leaf){throw 'Invalid rollback path'}
    $parent=[IO.Path]::GetFullPath((Split-Path (Split-Path $target)))
    $backup=[IO.Path]::GetFullPath((Join-Path $parent ('PhotoFaceInstallFailures\'+[guid]::NewGuid().ToString('N'))))
    if(-not $backup.StartsWith($parent+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Invalid rollback destination'}
    New-Item -ItemType Directory -Path $backup -Force | Out-Null
    Move-Item -LiteralPath $target -Destination (Join-Path $backup $entry.leaf)
   } catch {Write-Warning 'Could not move the incomplete PhotoFace installation. Close the game and inspect the two PhotoFace folders before retrying.'}
  }
 }
 Write-Error $installError
 exit 1
}
