﻿$ErrorActionPreference='Stop'
try {
 $receipt=Join-Path $PSScriptRoot 'photoface-install.json'
 if(-not(Test-Path -LiteralPath $receipt)){throw 'Run Uninstall.cmd from the installed ue4ss\Mods\PhotoFaceAccess folder.'}
 if(Get-Process -Name 'inZOI*','BlueClient*' -ErrorAction SilentlyContinue){throw 'Close inZOI before uninstalling.'}
 $r=Get-Content -LiteralPath $receipt -Raw -Encoding UTF8 | ConvertFrom-Json
 $access=[IO.Path]::GetFullPath($r.access)
 $native=[IO.Path]::GetFullPath($r.native)
 if($access -ne [IO.Path]::GetFullPath($PSScriptRoot) -or (Split-Path $access -Leaf) -ne 'PhotoFaceAccess' -or (Split-Path $native -Leaf) -ne 'PhotoFace_9CYVRD'){throw 'Invalid installation receipt.'}
 # Preserve the complete installation and local photo cache; never touch saves or other mods.
 $tag=Get-Date -Format 'yyyyMMdd-HHmmss'
 $nativeBackup=Join-Path (Split-Path (Split-Path $native)) ('PhotoFaceBackups\'+$tag)
 $accessBackup=Join-Path (Split-Path (Split-Path $access)) ('PhotoFaceBackups\'+$tag)
 foreach($p in Get-CimInstance Win32_Process -Filter "Name='pythonw.exe' OR Name='python.exe'"){
  if($p.ExecutablePath -and $p.ExecutablePath.StartsWith($access+'\',[StringComparison]::OrdinalIgnoreCase)){Stop-Process -Id $p.ProcessId}
 }
 New-Item -ItemType Directory -Force -Path $nativeBackup,$accessBackup | Out-Null
 if(Test-Path -LiteralPath $native){Move-Item -LiteralPath $native -Destination (Join-Path $nativeBackup 'PhotoFace_9CYVRD')}
 Move-Item -LiteralPath $access -Destination (Join-Path $accessBackup 'PhotoFaceAccess')
 Write-Host 'PhotoFace disabled. Its folders were moved to PhotoFaceBackups outside the active mod directories. Your local data remains in that backup; delete it manually if no longer needed.'
} catch {Write-Error $_;exit 1}
