PhotoFace 0.1.1-alpha — quick installation / быстрая установка

ENGLISH
1. Close inZOI. Install UE4SS separately:
   https://www.nexusmods.com/inzoi/mods/243
2. Extract the whole Main File ZIP into an ordinary writable folder.
3. Run Install.cmd. Choose the inZOI folder containing BlueClient if asked.
4. Start the game, open Create a Zoi and the small PhotoFace button.
5. Select 3–5 JPEG/PNG/WebP photos: front and moderate turns to both sides.
   Use a neutral expression and clear face. Export HEIC to JPEG first.
6. Start fitting; leave the camera and character unchanged until it finishes.
   The first calibration can take several minutes. Afterwards use Undo or refine
   the normal game face controls. Save a separate character before experimenting.

Windows x64 / Steam inZOI. Checked build: 20261019.16318.W-336312.
Codex, Blender, ModKit and a system Python installation are not required.
UE4SS is NOT included. If a required DLL is missing, install/repair Microsoft's
supported Visual C++ x64 runtime:
https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist
The game must expose its compatible local API at 127.0.0.1:11212.
A full fitting session on a different PC has not yet been completed. Other game
versions, non-Steam editions and female/other base heads require further testing.
Vortex one-click installation is not supported.

Privacy: photo processing is local. MediaPipe is pinned to 0.10.21 rather than the
newer telemetry-enabled package. PhotoFace has no upload or automatic analytics
feature. The game API client bypasses proxies and refuses redirects. A bounded
inference/idle test observed no non-loopback TCP connections; this is not a universal
network guarantee. Your cache is kept under Windows local application data:
%LOCALAPPDATA%\PhotoFace\cache\<installation-id>
It can contain chosen photo paths, measurements, editor screenshots and error logs.
Check it before sharing anything. No author's photos or personal results are bundled.
Original photographs are not modified or deleted.

Diagnostics: run Diagnose.cmd from the INSTALLED ue4ss\Mods\PhotoFaceAccess folder
while the game is open. If its local API is missing, this game build is not supported.
Do not expose the API to the internet or open router ports.

Uninstall/update: close the game and run Uninstall.cmd from the installed
PhotoFaceAccess folder. Only the two PhotoFace mod folders are moved to
PhotoFaceBackups outside active mod directories. The local cache is preserved.
Other mods, UE4SS itself and saves are untouched. Install the update afterwards.
Existing PhotoFace installations are never silently overwritten. Failed partial
installations are moved into PhotoFaceInstallFailures folders for inspection.

Limits: approximate shape fitting, no guaranteed exact copy/90% likeness, no skin
photo projection, ear fitting, automatic facial-hair transfer, strict profile 90-degree
fitting or direct ARKit/TrueDepth/Live Link Face scan import. A stock game head and
stock skin are required. Full end-to-end tests were developed on a male stock head.
15 UI languages are included.

Licenses: THIRD-PARTY-NOTICES.txt, DEPENDENCIES.json, PHOTOFACE-PERMISSIONS.txt and
LEGAL. The source companion PhotoFace-0.1.1-sources.zip is provided on the same mod
page for the applicable mathematical-library components; it is not needed to run.

РУССКИЙ
1. Закрой игру. Отдельно установи UE4SS по ссылке выше и инструкции его автора.
2. Распакуй весь основной архив в обычную папку и запусти Install.cmd.
   При необходимости укажи корень inZOI с подпапкой BlueClient.
3. Открой создание персонажа и маленькую кнопку PhotoFace.
4. Выбери 3–5 JPEG/PNG/WebP: анфас и повороты в обе стороны, нейтральная мимика,
   открытое лицо. HEIC сначала экспортируй в JPEG.
5. Начни подбор. До завершения не меняй камеру и персонажа. Первая калибровка
   может занять несколько минут. Результат можно отменить или поправить в редакторе.
   До экспериментов сохрани отдельную копию персонажа.

Codex, Blender, ModKit и системный Python не нужны. Steam и «Документы», включая
OneDrive, определяются установщиком. Требуются Windows x64, UE4SS и совместимая
сборка игры. При ошибке отсутствующей DLL используй официальный Visual C++ x64.
Проверена сборка 20261019.16318.W-336312; полный тест на другом ПК пока не выполнен.
Подбор разрабатывался на штатной мужской голове; другие головы требуют проверки.

Фото обрабатываются локально, без функции отправки в PhotoFace. Использована
MediaPipe 0.10.21 вместо новой версии с телеметрией. Ограниченный тест не выявил
нелокальных TCP-соединений. Кэш, пути фото, измерения, снимки редактора и ошибки
хранятся в %LOCALAPPDATA%\PhotoFace\cache. Проверяй их перед передачей кому-либо.
Личных фото и параметров автора в архиве нет. Исходные фото не изменяются.

Диагностика — Diagnose.cmd из установленной папки PhotoFaceAccess, когда игра открыта.
Удаление — Uninstall.cmd из этой же папки после закрытия игры. Папки мода сохранятся
в резервных каталогах вне активных модов; кэш, остальные моды и сохранения останутся.
Для обновления сначала удали прежнюю версию, затем установи новую.

Это приблизительная редактируемая форма, а не гарантированная копия лица на 90%.
Нет переноса кожи/щетины из фото, подбора ушей, строгого профиля 90° или импорта
скана Live Link Face. Нужны штатная голова и кожа игры. Лицензии и сведения о
сторонних компонентах находятся в указанных выше файлах.
